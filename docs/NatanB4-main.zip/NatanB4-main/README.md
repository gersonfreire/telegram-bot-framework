
![138322189-2db8df52-9dcb-40a0-88a8-c365466bd33d](https://user-images.githubusercontent.com/89656623/214648213-d698ffe7-0c15-4728-8ac0-3e241011cc78.gif)

---

<!--START_SECTION:waka-->
![Code Time](http://img.shields.io/badge/Code%20Time-80%20hrs%2030%20mins-blue)

![Profile Views](http://img.shields.io/badge/Profile%20Views-0-blue)

**🐱 My GitHub Data** 

> 📦 104.1 kB Used in GitHub's Storage 
 > 
> 🏆 183 Contributions in the Year 2024
 > 
> 🚫 Not Opted to Hire
 > 
> 📜 22 Public Repositories 
 > 
> 🔑 5 Private Repositories 
 > 
**I'm an Early 🐤** 

```text
🌞 Morning                2644 commits        ██████░░░░░░░░░░░░░░░░░░░   25.92 % 
🌆 Daytime                6439 commits        ████████████████░░░░░░░░░   63.12 % 
🌃 Evening                799 commits         ██░░░░░░░░░░░░░░░░░░░░░░░   07.83 % 
🌙 Night                  319 commits         █░░░░░░░░░░░░░░░░░░░░░░░░   03.13 % 
```
📅 **I'm Most Productive on Wednesday** 

```text
Monday                   2011 commits        █████░░░░░░░░░░░░░░░░░░░░   19.71 % 
Tuesday                  1576 commits        ████░░░░░░░░░░░░░░░░░░░░░   15.45 % 
Wednesday                2218 commits        █████░░░░░░░░░░░░░░░░░░░░   21.74 % 
Thursday                 2141 commits        █████░░░░░░░░░░░░░░░░░░░░   20.99 % 
Friday                   2081 commits        █████░░░░░░░░░░░░░░░░░░░░   20.40 % 
Saturday                 82 commits          ░░░░░░░░░░░░░░░░░░░░░░░░░   00.80 % 
Sunday                   92 commits          ░░░░░░░░░░░░░░░░░░░░░░░░░   00.90 % 
```


📊 **This Week I Spent My Time On** 

```text
🕑︎ Time Zone: America/Sao_Paulo

💬 Programming Languages: 
JavaScript               2 hrs 40 mins       ███████████████████░░░░░░   75.10 % 
TypeScript               43 mins             █████░░░░░░░░░░░░░░░░░░░░   20.24 % 
Bash                     6 mins              █░░░░░░░░░░░░░░░░░░░░░░░░   03.16 % 
CSS                      1 min               ░░░░░░░░░░░░░░░░░░░░░░░░░   00.80 % 
JSON                     0 secs              ░░░░░░░░░░░░░░░░░░░░░░░░░   00.33 % 

🔥 Editors: 
VS Code                  3 hrs 32 mins       █████████████████████████   100.00 % 

🐱‍💻 Projects: 
cifa_backend             1 hr 13 mins        █████████░░░░░░░░░░░░░░░░   34.32 % 
itau_v3_mock             50 mins             ██████░░░░░░░░░░░░░░░░░░░   23.72 % 
blingxsap_backend        24 mins             ███░░░░░░░░░░░░░░░░░░░░░░   11.29 % 
xmle-dashboard           22 mins             ███░░░░░░░░░░░░░░░░░░░░░░   10.71 % 
portal-titulos-backend   22 mins             ███░░░░░░░░░░░░░░░░░░░░░░   10.33 % 

💻 Operating System: 
WSL                      3 hrs 33 mins       █████████████████████████   100.00 % 
```

**I Mostly Code in JavaScript** 

```text
JavaScript               27 repos            █████████████░░░░░░░░░░░░   50.94 % 
TypeScript               14 repos            ███████░░░░░░░░░░░░░░░░░░   26.42 % 
Python                   5 repos             ██░░░░░░░░░░░░░░░░░░░░░░░   09.43 % 
C#                       2 repos             █░░░░░░░░░░░░░░░░░░░░░░░░   03.77 % 
CSS                      1 repo              ░░░░░░░░░░░░░░░░░░░░░░░░░   01.89 % 
```



**Timeline**

![Lines of Code chart](https://raw.githubusercontent.com/NatanB4/NatanB4/main/assets/bar_graph.png)


 Last Updated on 10/05/2024 16:36:54 UTC
<!--END_SECTION:waka-->
    
  <a href="mailto:natanbarbosa027@gmail.com"><img src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>

